Stack kit, design C2R5 (October 2026)

plasma/: two 14 ga steel side plates, DXF R12 in inches, 1.71 mm kerf, HARD 0 WARN 0.
laser/: eight 6 mm Baltic birch parts, DXF in mm, no kerf compensation (0.2 mm kerf assumed).
print/: PETG STL files plus sliced 3MF plates for a Bambu X1C (re-slice in Bambu Studio before a real print).

Measure your own devices, your birch thickness and your router before cutting. The numbers are for the devices listed on the page.

Hardware
- M4 x 12 button head bolts: 40
- M4 nuts (captured in the bracket pockets): 40
- 10 x 3 mm N52 disc magnets: 16
- VHB tape: a strip
- Cord velcro: a few
- 30-minute epoxy: one tube

Build order
1. Test print first: one front bracket and one plain bracket. Check that an M4 nut drops into its pocket and a 4 mm peg enters a 4.4 hole in a birch offcut.
2. Plasma the two side plates, 260 x 276, twenty 5 mm holes each. Knock off the dross, scuff, degrease, paint satin black.
3. Laser the eight birch parts: tray, floor, two shelves, two rails, spine, grille. Epoxy a magnet into each of the eight grille pockets.
4. Print the four plates on the X1C in PETG: plate A is the brackets and stops, B, C and D are the three cradles.
5. Bolt 10 brackets to the left plate, flat on the bench. The two tray brackets stand up, the floor brackets above them hang down.
6. Lay down the tray, then the floor, then the cradles. Drop shelf 1, shelf 2 and the two rails onto their pegs.
7. Bolt the right plate on with its 10 brackets.
8. Push the spine into the three ring sockets. Slide the bricks in from the back: two at the rear with DC ends forward, the router brick across the front.
9. Slide the devices in. Run every DC lead down the rear right corner, along the tray's right lane, to its brick. Set the router on the rails against its two stops.
10. Set the grille on. The magnets in the brackets meet the magnets in the grille, 15 mm off the device fronts.

https://promptaieducation.com/stack/
