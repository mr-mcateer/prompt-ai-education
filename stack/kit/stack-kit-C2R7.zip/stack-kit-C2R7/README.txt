Stack kit, design C2R7 (October 2026)

plasma/: two 14 ga steel side plates, ten 12.7 x 26.7 mm slots each, plasma only (no drilling, no marking). DXF R12 in inches, 1.71 mm kerf, HARD 0 WARN 0. Cut both plates in one program, outside face up.
laser/: eight 6 mm Baltic birch parts, DXF in mm, no kerf compensation (0.2 mm kerf assumed).
print/: PETG STL files plus five sliced 3MF plates for a Bambu X1C, A brackets, B to D cradles, E the 20 slot caps (re-slice in Bambu Studio before a real print).

Measure your own devices, your birch thickness and your router before cutting. The numbers are for the devices listed on the page.

Hardware
- M4 x 12 flanged button head bolts, black, ISO 7380-2: 40
- M4 nuts (captured in the bracket pockets): 40
- 10 x 3 mm N52 disc magnets: 16
- VHB tape: a strip
- Cord velcro: a few
- 30-minute epoxy: one tube

Build order
1. Test print first: one porthole cap and one plain bracket. Check that an M4 nut drops into its pocket and a 4 mm peg enters a 4.4 hole in a birch offcut.
2. Cut one slot in scrap 14 ga. The cap's spigot must drop in by hand with a little play. If it will not, flap disc the slot edge. Do not drill.
3. Plasma both side plates in one program, outside face up: 260 x 276, ten 12.7 x 26.7 mm slots each. Flap disc the edges, scuff, degrease, paint satin black.
4. Laser the eight birch parts: tray, floor, two shelves, two rails, spine, grille. Epoxy a magnet into each of the eight grille pockets.
5. Print the five plates on the X1C in PETG: A is the brackets and stops, B, C and D are the three cradles, E is the 20 caps.
6. Lay the left plate inside face up on two blocks. Set each bracket over its slot with its nut in the pocket. From below, push a cap's spigot into the slot and run two M4 x 12 through cap, steel and bracket. Push the bracket down as you snug it, 0.4 to 0.6 Nm.
7. Lay down the tray, then the floor, then the cradles. Drop shelf 1, shelf 2 and the two rails onto their pegs.
8. Bolt the right plate on the same way: 10 brackets, 10 caps. If a level rocks, loosen its low bracket, lift it in its slot and snug it again.
9. Push the spine into the three ring sockets. Slide the bricks in from the back, then the devices. Run every DC lead down the rear right corner and along the tray's right lane. Set the router on the rails against its two stops.
10. Set the grille on. The magnets in the brackets meet the magnets in the grille, 15 mm off the device fronts.

https://promptaieducation.com/stack/
